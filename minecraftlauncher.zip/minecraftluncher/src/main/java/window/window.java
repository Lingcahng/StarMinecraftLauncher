package window;
import java.awt.*;
import javax.swing.*;

public class window {
    private void windows_make(){
        JFrame j=new JFrame();

    }
}
